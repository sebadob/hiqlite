import{a as t}from"../chunks/entry.Cp4mo8_5.js";export{t as start};
