import{a as t}from"../chunks/entry.flpNJx67.js";export{t as start};
