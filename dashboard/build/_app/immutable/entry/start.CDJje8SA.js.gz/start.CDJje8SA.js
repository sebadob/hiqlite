import{a as t}from"../chunks/entry.CtHEJy8O.js";export{t as start};
