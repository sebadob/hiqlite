import{a as t}from"../chunks/entry.fcdV1YYN.js";export{t as start};
