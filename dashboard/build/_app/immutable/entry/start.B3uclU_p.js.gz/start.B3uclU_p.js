import{a as t}from"../chunks/entry.EPg1O8V_.js";export{t as start};
