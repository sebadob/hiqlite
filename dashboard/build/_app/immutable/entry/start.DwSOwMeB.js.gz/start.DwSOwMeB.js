import{a as t}from"../chunks/entry.DhmllS4k.js";export{t as start};
