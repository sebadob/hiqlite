import { e } from "./TbIIo73h.js";
e();
