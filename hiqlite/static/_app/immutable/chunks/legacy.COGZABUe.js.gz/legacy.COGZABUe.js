import{e as m}from"./runtime.BELmqrWi.js";m();
