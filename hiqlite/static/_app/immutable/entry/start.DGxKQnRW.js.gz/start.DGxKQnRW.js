import{a as t}from"../chunks/entry.CHNKqPza.js";export{t as start};
