import { l as o, a as r } from "../chunks/X1x_5zTn.js";
export {
  o as load_css,
  r as start
};
