import { l as o, a as r } from "../chunks/D5jO3Q6y.js";
export {
  o as load_css,
  r as start
};
