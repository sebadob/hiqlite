import{a as t}from"../chunks/entry.BeB68v5M.js";export{t as start};
