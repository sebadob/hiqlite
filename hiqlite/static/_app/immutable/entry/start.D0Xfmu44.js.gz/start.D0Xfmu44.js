import{a as t}from"../chunks/entry.12wClB10.js";export{t as start};
