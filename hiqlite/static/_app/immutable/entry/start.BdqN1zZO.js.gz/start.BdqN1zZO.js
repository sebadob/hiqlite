import{a as t}from"../chunks/entry.t3P_F_QZ.js";export{t as start};
