import{a as t}from"../chunks/entry.CcB8h9xI.js";export{t as start};
