import{a as t}from"../chunks/entry.6jbl5vD4.js";export{t as start};
