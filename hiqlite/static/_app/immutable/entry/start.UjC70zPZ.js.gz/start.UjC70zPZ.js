import{a as t}from"../chunks/entry.Cj2JkjWf.js";export{t as start};
