import{a as t}from"../chunks/entry.cJAWZgOL.js";export{t as start};
