import{a as t}from"../chunks/entry.nRnZ7JKo.js";export{t as start};
