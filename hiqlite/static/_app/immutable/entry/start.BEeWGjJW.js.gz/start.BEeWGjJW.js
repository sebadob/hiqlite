import{a as t}from"../chunks/entry.CrFjipKm.js";export{t as start};
