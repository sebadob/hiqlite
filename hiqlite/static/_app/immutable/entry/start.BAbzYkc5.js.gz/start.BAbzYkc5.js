import{a as t}from"../chunks/entry.BCaYY7Xo.js";export{t as start};
