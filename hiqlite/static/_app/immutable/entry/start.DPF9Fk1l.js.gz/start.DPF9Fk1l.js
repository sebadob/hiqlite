import{a as t}from"../chunks/entry.O1uyTrA1.js";export{t as start};
