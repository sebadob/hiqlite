import{a as t}from"../chunks/entry.B1T0ePqP.js";export{t as start};
