import{a as t}from"../chunks/entry.UXXiO0kk.js";export{t as start};
