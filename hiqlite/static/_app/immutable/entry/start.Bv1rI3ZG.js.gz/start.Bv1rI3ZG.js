import{a as t}from"../chunks/entry.EtE1iUMO.js";export{t as start};
