import{a as t}from"../chunks/entry.Bry-63aF.js";export{t as start};
