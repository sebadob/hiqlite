import{a as t}from"../chunks/B1VMp0bd.js";export{t as start};
