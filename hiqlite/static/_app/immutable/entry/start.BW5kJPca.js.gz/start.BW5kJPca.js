import{a as t}from"../chunks/entry.CGXmJjhx.js";export{t as start};
