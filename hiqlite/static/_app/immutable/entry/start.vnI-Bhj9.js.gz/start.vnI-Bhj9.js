import{a as t}from"../chunks/entry.6TCMQ4fP.js";export{t as start};
