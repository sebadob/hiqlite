import{a as t}from"../chunks/entry.DPeLRS5w.js";export{t as start};
