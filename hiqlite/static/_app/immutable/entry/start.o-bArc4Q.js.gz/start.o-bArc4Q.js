import{a as t}from"../chunks/entry.CUsifCq-.js";export{t as start};
