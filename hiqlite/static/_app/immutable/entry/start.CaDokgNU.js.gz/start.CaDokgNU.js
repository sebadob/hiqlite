import{a as t}from"../chunks/entry.DZTflNfG.js";export{t as start};
