import{a as t}from"../chunks/entry.CY_4QpUk.js";export{t as start};
