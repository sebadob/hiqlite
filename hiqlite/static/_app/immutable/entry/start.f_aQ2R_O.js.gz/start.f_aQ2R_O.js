import{a as t}from"../chunks/entry.DsMc1LyU.js";export{t as start};
