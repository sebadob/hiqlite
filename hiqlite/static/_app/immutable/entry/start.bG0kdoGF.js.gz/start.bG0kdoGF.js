import{a as t}from"../chunks/entry.CexTxBwC.js";export{t as start};
